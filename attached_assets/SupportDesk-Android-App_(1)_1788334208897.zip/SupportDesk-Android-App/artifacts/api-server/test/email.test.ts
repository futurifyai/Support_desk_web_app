import { beforeEach, describe, expect, it, vi } from "vitest";

const mailState = vi.hoisted(() => ({
  createTransport: vi.fn(),
  sendMail: vi.fn(),
}));

vi.mock("nodemailer", () => ({
  default: { createTransport: mailState.createTransport },
}));

import { sendNewTicketAdminEmail, sendTicketResolvedEmail } from "../src/lib/email";

beforeEach(() => {
  process.env["EMAIL_USER"] = "sender@example.com";
  process.env["EMAIL_PASS"] = "test-password";
  process.env["REPLIT_DEV_DOMAIN"] = "support.example";
  delete process.env["ADMIN_NOTIFY_EMAIL"];
  mailState.sendMail.mockReset().mockResolvedValue(undefined);
  mailState.createTransport.mockReset().mockReturnValue({ sendMail: mailState.sendMail });
});

describe("new ticket admin email", () => {
  it("uses the fallback recipient and includes escaped ticket details and admin link", async () => {
    await sendNewTicketAdminEmail({
      ticketId: "ticket-123",
      productName: "Workspace <Pro>",
      userName: "Priya & Co",
      userEmail: "priya@example.com",
      description: "Sync fails <after> login.",
    });

    expect(mailState.sendMail).toHaveBeenCalledWith(expect.objectContaining({
      to: "futurifyai@gmail.com",
      subject: "New ticket raised: Workspace <Pro>",
    }));
    const message = mailState.sendMail.mock.calls[0]?.[0] as { html: string };
    expect(message.html).toContain("Priya &amp; Co");
    expect(message.html).toContain("Workspace &lt;Pro&gt;");
    expect(message.html).toContain("Sync fails &lt;after&gt; login.");
    expect(message.html).toContain("priya@example.com");
    expect(message.html).toContain("View Ticket");
    expect(message.html).toContain("supportdesk://ticket/ticket-123");
  });

  it("uses ADMIN_NOTIFY_EMAIL when configured", async () => {
    process.env["ADMIN_NOTIFY_EMAIL"] = "support-team@example.com";

    await sendNewTicketAdminEmail({
      ticketId: "ticket-456",
      productName: "Billing",
      userName: "Sam",
      userEmail: "sam@example.com",
      description: "A billing invoice is missing.",
    });

    expect(mailState.sendMail).toHaveBeenCalledWith(expect.objectContaining({
      to: "support-team@example.com",
      subject: "New ticket raised: Billing",
    }));
  });
});

describe("resolved ticket email", () => {
  it("asks the user to rate and close the ticket with the three-day warning", async () => {
    await sendTicketResolvedEmail({
      ticketId: "ticket-789",
      productName: "Workspace <Pro>",
      userEmail: "priya@example.com",
    });

    expect(mailState.sendMail).toHaveBeenCalledWith(expect.objectContaining({
      to: "priya@example.com",
      subject: "Your ticket has been resolved: Workspace <Pro>",
    }));
    const message = mailState.sendMail.mock.calls[0]?.[0] as { html: string };
    expect(message.html).toContain("has been resolved");
    expect(message.html).toContain("rate your experience");
    expect(message.html).toContain("Rate and Close Ticket");
    expect(message.html).toContain("If we don't hear back within 3 days, your account may be temporarily suspended until you close this ticket.");
    expect(message.html).toContain("supportdesk://user-ticket/ticket-789");
  });
});