import { Stack } from "expo-router";

export default function AdminLayout() {
  return (
    <Stack screenOptions={{ headerShown: false, animation: "slide_from_right" }}>
      <Stack.Screen name="dashboard"  options={{ animation: "fade" }} />
      <Stack.Screen name="analytics"  options={{ animation: "fade" }} />
      <Stack.Screen name="user-stats" options={{ animation: "fade" }} />
      <Stack.Screen name="access"      options={{ animation: "fade" }} />
      <Stack.Screen name="audit-log"  options={{ animation: "fade" }} />
      <Stack.Screen name="profile"    options={{ animation: "fade" }} />
      <Stack.Screen name="ticket/[id]" />
    </Stack>
  );
}
