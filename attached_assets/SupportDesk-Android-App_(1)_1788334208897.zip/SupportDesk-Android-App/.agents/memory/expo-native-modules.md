---
name: Expo native modules
description: Rules for adding native React Native modules to an Expo artifact in this monorepo.
---

Native React Native modules must be declared by the consuming Expo artifact and use the version compatible with that artifact’s Expo SDK.

**Why:** A dependency at the monorepo root can make TypeScript and Metro resolution appear healthy while Expo Go’s bundled native binary uses a different module version, creating a mobile-only runtime mismatch.

**How to apply:** When adding a native module, use the Expo SDK-compatible release, put it in the mobile artifact’s manifest, ensure the lockfile importer matches, and validate iOS and Android production bundles.