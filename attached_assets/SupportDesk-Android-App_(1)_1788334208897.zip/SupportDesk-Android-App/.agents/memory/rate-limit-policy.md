---
name: API rate-limit policy
description: Durable constraints for SupportDesk authentication throttling and deployment safety.
---

Authentication rate limits must use the shared PostgreSQL counter table and hashed client identifiers; do not replace them with a process-local limiter.

**Why:** Multiple API instances or restarts make in-memory counters ineffective, and an implicit proxy configuration can cause all users behind a proxy to share one bucket.

**How to apply:** Keep the ordered schema migration alongside the rate-limit table definition. Production startup must require an explicit trusted-proxy hop configuration before relying on the client IP.