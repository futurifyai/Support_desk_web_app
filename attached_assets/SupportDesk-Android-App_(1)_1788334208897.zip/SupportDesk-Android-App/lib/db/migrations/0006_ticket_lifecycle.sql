-- Ticket lifecycle timestamps and user activity controls.
ALTER TABLE "tickets" ADD COLUMN IF NOT EXISTS "closed_at" timestamp;
ALTER TABLE "tickets" ADD COLUMN IF NOT EXISTS "reminder_sent_at" timestamp;
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "is_active" boolean NOT NULL DEFAULT true;
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "suspended_at" timestamp;